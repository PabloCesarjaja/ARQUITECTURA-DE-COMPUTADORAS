from tkinter import *
from tkinter import filedialog, messagebox

# -----------------------
# Tablas de instrucciones (R/I/J)
# -----------------------
r_inst = {
    "ADD": {"opcode": "000000", "funct": "100000"},
    "SUB": {"opcode": "000000", "funct": "100010"},
    "OR":  {"opcode": "000000", "funct": "100101"},
    # Shift and set instructions
    "SLL": {"opcode": "000000", "funct": "000000"},  # shamt used
    "SLT": {"opcode": "000000", "funct": "101010"}
}

i_inst = {
    "ADDI": "001000",
    "ANDI": "001100",
    "ORI":  "001101",
    "SLTI": "001010",
    "BEQ":  "000100",
    "BNE":  "000101",
    "LW":   "100011",
    "SW":   "101011"
}

j_inst = {
    "J":   "000010",
    "JAL": "000011"
}

# -----------------------
# Utilidades binarias
# -----------------------
def tobin_unsigned(n, bits):
    return format(int(n) & ((1 << bits) - 1), f'0{bits}b')

def tobin_signed(n, bits):
    n_int = int(n)
    mask = (1 << bits) - 1
    return format(n_int & mask, f'0{bits}b')

# -----------------------
# Conversores por tipo
# -----------------------
def convert_r(op, rd, rs, rt):
    """
    Convierte R-type. Nota: para SLL interpretamos los argumentos como:
    SLL rd rt shamt (se pasa desde parser como rd, rs, rt -> donde rs=rt_arg y rt=shamt)
    """
    opu = op.upper()
    if opu not in r_inst:
        return None
    opcode = r_inst[opu]["opcode"]
    funct = r_inst[opu]["funct"]

    # Caso especial: SLL (no usa 'rs', usa shamt)
    if opu == "SLL":
        # parámetros esperados (según parse_line_auto) son: rd, rs, rt
        # aqui rs = rt_arg, rt = shamt_arg
        try:
            rd_val = int(rd, 0)
            rt_arg = int(rs, 0)   # el segundo token es el registro fuente (rt)
            shamt_arg = int(rt, 0)  # el tercer token es el shamt
        except:
            return None
        rsb = tobin_unsigned(0, 5)          # rs = 0
        rtb = tobin_unsigned(rt_arg, 5)     # rt = rt_arg
        rdb = tobin_unsigned(rd_val, 5)     # rd = rd_val
        shamt = tobin_unsigned(shamt_arg, 5)
        return (opcode, rsb, rtb, rdb, shamt, funct)

    # Caso general R: OP RD RS RT
    try:
        rdb = tobin_unsigned(rd, 5)
        rsb = tobin_unsigned(rs, 5)
        rtb = tobin_unsigned(rt, 5)
    except:
        return None
    shamt = "00000"
    return (opcode, rsb, rtb, rdb, shamt, funct)

def convert_i(tokens):
    """
    tokens: [OP, arg1, arg2, ...]
    Soporta:
      - ADDI/ANDI/ORI/SLTI: OP RT RS IMM   (tokens = [OP, rt, rs, imm])
      - BEQ/BNE: OP RS RT OFFSET           (tokens = [OP, rs, rt, offset])
      - LW/SW: OP RT OFFSET(BASE)  OR OP RT OFFSET BASE
    Las constantes (imm/offset) se interpretan con int(..., 0) para aceptar 0x..
    """
    if not tokens:
        return None
    op = tokens[0].upper()
    if op not in i_inst:
        return None
    opcode = i_inst[op]
    args = tokens[1:]

    # LW / SW
    if op in ("LW", "SW"):
        if len(args) < 2:
            return None
        try:
            rt = int(args[0], 0)
        except:
            return None
        addr_token = args[1]
        if "(" in addr_token and ")" in addr_token:
            try:
                off_str = addr_token.split("(")[0]
                base_str = addr_token.split("(")[1].split(")")[0]
                imm = int(off_str, 0)
                rs = int(base_str, 0)
            except:
                return None
            return (opcode, tobin_unsigned(rs,5), tobin_unsigned(rt,5), tobin_signed(imm,16))
        else:
            # fallback: OP RT OFFSET BASE
            if len(args) >= 3:
                try:
                    imm = int(args[1], 0)
                    rs = int(args[2], 0)
                    return (opcode, tobin_unsigned(rs,5), tobin_unsigned(rt,5), tobin_signed(imm,16))
                except:
                    return None
            return None

    # BEQ / BNE
    if op in ("BEQ", "BNE"):
        if len(args) != 3:
            return None
        try:
            rs = int(args[0], 0); rt = int(args[1], 0); imm = int(args[2], 0)
            return (opcode, tobin_unsigned(rs,5), tobin_unsigned(rt,5), tobin_signed(imm,16))
        except:
            return None

    # ADDI, ANDI, ORI, SLTI
    if op in ("ADDI", "ANDI", "ORI", "SLTI"):
        if len(args) != 3:
            return None
        try:
            rt = int(args[0], 0); rs = int(args[1], 0); imm = int(args[2], 0)
            return (opcode, tobin_unsigned(rs,5), tobin_unsigned(rt,5), tobin_signed(imm,16))
        except:
            return None

    return None

def convert_j(tokens):
    """
    tokens: [OP, address]
    address decimal o hex (0x)
    """
    if not tokens or len(tokens) < 2:
        return None
    op = tokens[0].upper()
    if op not in j_inst:
        return None
    opcode = j_inst[op]
    addr_str = tokens[1]
    try:
        addr = int(addr_str, 0)  # base 0 acepta hex 0x...
    except:
        return None
    addr26 = addr & ((1 << 26) - 1)
    return (opcode, tobin_unsigned(addr26, 26))

# -----------------------
# Parser automático actualizado
# -----------------------
def parse_line_auto(line):
    if not line:
        return None
    parts = line.strip().split()
    if len(parts) == 0:
        return None
    op = parts[0].upper()

    # R explicit
    if op in r_inst:
        # SLL also arrives here; we accept 4 tokens for R-case
        if len(parts) == 4:
            try:
                rd = int(parts[1], 0); rs = int(parts[2], 0); rt = int(parts[3], 0)
                return convert_r(op, rd, rs, rt)
            except:
                return None
        else:
            return None

    # I explicit
    if op in i_inst:
        return convert_i(parts)

    # J explicit
    if op in j_inst:
        return convert_j(parts)

    # Heurística: 4 tokens -> intentar R (si los 3 últimos son enteros)
    if len(parts) == 4:
        try:
            rd = int(parts[1], 0); rs = int(parts[2], 0); rt = int(parts[3], 0)
            return convert_r(op, rd, rs, rt)
        except:
            pass

    # Heurística: 2 tokens -> intentar J si segundo es numérico
    if len(parts) == 2:
        try:
            _ = int(parts[1], 0)
            return convert_j(parts)
        except:
            pass

    return None

# -----------------------
# GUI (igual que antes, pero con parser automático mejorado)
# -----------------------
def mainwin():
    win = Tk()
    win.title("Decodificador mixto (R/I/J) - Entrada")
    win.geometry('650x320')
    win.tk.call('tk', 'scaling', 2.0)

    Label(win, text="Puedes escribir instrucciones R, I y J mezcladas.").pack(pady=(12,6))
    Label(win, text="Formato general (ejemplos):").pack()
    Label(win, text="R: ADD rd rs rt    | I: ADDI rt rs imm  | LW rt offset(base)  | J: J address").pack(pady=(0,8))

    def abrir_manual():
        win.destroy()
        win_manual()

    def abrir_archivo():
        file_path = filedialog.askopenfilename(
            title="Seleccionar archivo de instrucciones",
            filetypes=[("Archivos de texto", "*.txt")]
        )
        if not file_path:
            return
        instrucciones = []
        invalid_lines = []
        try:
            with open(file_path, "r") as f:
                for lineno, linea in enumerate(f, start=1):
                    parsed = parse_line_auto(linea)
                    if parsed:
                        instrucciones.append(parsed)
                    else:
                        invalid_lines.append(lineno)
            if instrucciones:
                if invalid_lines:
                    messagebox.showwarning("Advertencia",
                        f"Algunas líneas no se pudieron parsear y serán ignoradas (líneas: {invalid_lines}).")
                win.destroy()
                winsave(instrucciones)
            else:
                messagebox.showerror("Error", "No se encontraron instrucciones válidas en el archivo.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo leer el archivo:\n{e}")

    Button(win, text="Escribir instrucciones manualmente", width=40, command=abrir_manual).pack(pady=8)
    Button(win, text="Cargar desde archivo .txt", width=40, command=abrir_archivo).pack(pady=6)
    Button(win, text="Salir", command=win.destroy).pack(pady=6)

    win.mainloop()

def win_manual():
    w = Tk()
    w.title("Ingresar instrucciones manualmente (mixtas)")
    w.geometry('760x520')
    w.tk.call('tk', 'scaling', 2.0)

    Label(w, text="Escribe tus instrucciones (una por línea). Puedes mezclar R, I y J.").pack(pady=8)
    Label(w, text="Ejemplos:\n  ADD 3 1 2\n  ADDI 2 1 -5\n  LW 2 16(3)\n  SLL 13 10 2\n  J 0x400").pack()

    text_box = Text(w, height=24, width=100)
    text_box.pack(pady=10)

    def procesar():
        contenido = text_box.get("1.0", END).strip()
        lineas = contenido.splitlines()
        instrucciones = []
        invalid_lines = []
        for idx, linea in enumerate(lineas, start=1):
            parsed = parse_line_auto(linea)
            if parsed:
                instrucciones.append(parsed)
            else:
                invalid_lines.append(idx)
        if not instrucciones:
            messagebox.showerror("Error", "No se encontraron instrucciones válidas en el texto.")
            return
        if invalid_lines:
            messagebox.showwarning("Advertencia",
                f"Algunas líneas no se pudieron parsear y serán ignoradas (líneas: {invalid_lines}).")
        w.destroy()
        winsave(instrucciones)

    Button(w, text="Convertir y Guardar", command=procesar).pack(pady=6)
    Button(w, text="Cancelar", command=w.destroy).pack()

    w.mainloop()

def winsave(instrucciones):
    """
    Pide nombre y guarda; ahora escribe UNA LÍNEA por instrucción con
    los 32 bits completos (opcode+campos...).
    """
    fwin = Tk()
    fwin.title("Guardar archivo")
    fwin.geometry('460x180')
    fwin.tk.call('tk', 'scaling', 2.0)

    Label(fwin, text="Nombre del archivo (sin extensión):").pack(pady=10)
    name_entry = Entry(fwin)
    name_entry.pack()

    def build_32bit_from_fields(instr):
        # instr es una tupla de campos binarios (strings)
        # R-type => (opcode, rs, rt, rd, shamt, funct)  -> 6 campos
        # I-type => (opcode, rs, rt, imm16)            -> 4 campos
        # J-type => (opcode, address26)                -> 2 campos
        if not instr:
            return None
        if len(instr) == 6:
            return ''.join(instr)  # opcode(6)+rs(5)+rt(5)+rd(5)+shamt(5)+funct(6)
        if len(instr) == 4:
            return ''.join(instr)  # opcode(6)+rs(5)+rt(5)+imm16(16)
        if len(instr) == 2:
            # opcode(6)+address26
            return ''.join(instr)
        # fallback: concatenar
        return ''.join(instr)

    def save():
        nom = name_entry.get().strip()
        if not nom:
            messagebox.showerror("Error", "Por favor, ingrese un nombre válido.")
            return
        try:
            with open(nom + ".txt", "w") as f:
                for instr in instrucciones:
                    line = build_32bit_from_fields(instr)
                    if line:
                        f.write(line + "\n")
            messagebox.showinfo("Éxito", f"Archivo '{nom}.txt' creado correctamente.")
            fwin.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo crear el archivo:\n{e}")

    Button(fwin, text="Guardar", command=save).pack(pady=6)
    Button(fwin, text="Cancelar", command=fwin.destroy).pack()

    fwin.mainloop()

if __name__ == "__main__":
    mainwin()
